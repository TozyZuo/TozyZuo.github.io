//
//  AppDelegate.h
//  flux.beta
//
//  Created by Michael Herf on 10/13/15.
//  Copyright © 2015 f.lux Software LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  main.m
//  flux.beta
//
//  Created by Michael Herf on 10/13/15.
//  Copyright © 2015 f.lux Software LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

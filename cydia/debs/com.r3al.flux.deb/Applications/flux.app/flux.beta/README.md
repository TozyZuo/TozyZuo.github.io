This is the default "single view" iOS template.

Could probably take some files out of it.

What's going on: we build an app using this code, and then we copy our app on top.
